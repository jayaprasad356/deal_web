<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
	$valid = 1;

    if(empty($_POST['bank_name'])) {
        $valid = 0;
        $error_message .= "Bank Name can not be empty<br>";
    } else {
		// Duplicate Bank checking
    	// current Bank name that is in the database
    	$statement = $pdo->prepare("SELECT * FROM contact_details WHERE bank_id=?");
		$statement->execute(array($_REQUEST['id']));
		$result = $statement->fetchAll(PDO::FETCH_ASSOC);
		foreach($result as $row) {
			$current_bank_name = $row['bank_name'];
		}

		$statement = $pdo->prepare("SELECT * FROM contact_details WHERE bank_name=? and bank_name!=?");
    	$statement->execute(array($_POST['bank_name'],$current_bank_name));
    	$total = $statement->rowCount();							
    	if($total) {
    		$valid = 0;
        	$error_message .= 'Bank Name already exists<br>';
    	}
    }

    if($valid == 1) {

    	
    	
		// updating into the database
		$statement = $pdo->prepare("UPDATE contact_details SET bank_name=?, bank_content=?, bank_customer=?, bank_website=?, bank_email=?, bank_fax=?   WHERE bank_id=?");
		$statement->execute(array($_POST['bank_name'],$_POST['bank_content'],$_POST['bank_customer'],$_POST['bank_website'],$_POST['bank_email'],$_POST['bank_fax'],$_REQUEST['id']));

    	$success_message = 'Bank Details is updated successfully.';
    }
}
?>
<?php

if(isset($_POST['form1']))
{ 

$extension = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
$name = $_POST["bank_name"];
$img_name = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '_', $name));

move_uploaded_file($_FILES["file"]["tmp_name"], "../assets/images/bank-logos/" .$img_name.".".$extension);
}
?>
<?php
if(!isset($_REQUEST['id'])) {
	header('location: logout.php');
	exit;
} else {
	// Check the id is valid or not
	$statement = $pdo->prepare("SELECT * FROM contact_details WHERE bank_id=?");
	$statement->execute(array($_REQUEST['id']));
	$total = $statement->rowCount();
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);
	if( $total == 0 ) {
		header('location: logout.php');
		exit;
	}
}
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Edit Bank Details</h1>
	</div>
	<div class="content-header-right">
		<a href="bank.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<?php							
foreach ($result as $row) {
	$bank_name = $row['bank_name'];
	$bank_content = $row['bank_content'];
	$bank_customer = $row['bank_customer'];
	$bank_website = $row['bank_website'];
	$bank_email = $row['bank_email'];
	$bank_fax = $row['bank_fax'];
}
?>

<section class="content">

  <div class="row">
    <div class="col-md-12">

		<?php if($error_message): ?>
		<div class="callout callout-danger">
		<h4>Please correct the following errors:</h4>
		<p>
		<?php echo $error_message; ?>
		</p>
		</div>
		<?php endif; ?>

		<?php if($success_message): ?>
		<div class="callout callout-success">
		<h4>Success:</h4>
		<p><?php echo $success_message; ?></p>
		</div>
		<?php endif; ?>

        <form class="form-horizontal" action="" enctype="multipart/form-data" method="post">

        <div class="box box-info">

            <div class="box-body">
                <div class="form-group">
                    <label for="" class="col-sm-2 control-label">Bank Name <span>*</span></label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="bank_name" value="<?php echo $bank_name; ?>">
                    </div>
                </div>
                <div class="form-group">
					<label for="" class="col-sm-2 control-label">Bank Content </label>
					<div class="col-sm-9">
						<textarea class="form-control" name="bank_content" id="editor1"><?php echo $bank_content; ?></textarea>
					</div>
				</div>
                
                <div class="form-group">
					<label for="" class="col-sm-2 control-label">Content No. </label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_customer" value="<?php echo $bank_customer; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Website </label>
					<div class="col-sm-9">
						<input type="text" class="form-control"  name="bank_website" value="<?php echo $bank_website; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Email </label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_email" value="<?php echo $bank_email; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Fax No. </label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_fax" value="<?php echo $bank_fax; ?>">
					</div>
				</div>
				<div class="form-group">
							<label for="" class="col-sm-2 control-label">Bank Logo </label>
							<div class="col-sm-3">
								<input type="file" class="form-control" name="file">
							</div>
							<div class="col-sm-3">
								<img src="../assets/images/bank-logos/<?php echo strtolower(str_replace(' ', '_', $bank_name));?>.png" alt="" style="width:100px;">
							</div>
							<div class="col-sm-3">
								<p>Image Type PNG Only</p>
							</div>
						</div>
                <div class="form-group">
                	<label for="" class="col-sm-2 control-label"></label>
                    <div class="col-sm-6">
                      <button type="submit" class="btn btn-success pull-left" name="form1">Update</button>
                    </div>
                </div>

            </div>

        </div>

        </form>



    </div>
  </div>

</section>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
            </div>
            <div class="modal-body">
                Are you sure want to delete this item?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>