<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
	$valid = 1;

    if(empty($_POST['pin_code'])) {
        $valid = 0;
        $error_message .= "IFSC Code can not be empty<br>";
    } 
	if(empty($_POST['pin_state'])) {
        $valid = 0;
        $error_message .= "State can not be empty<br>";
    }

    if(empty($_POST['pin_district'])) {
        $valid = 0;
        $error_message .= "District code can not be empty<br>";
    }
    
    if(empty($_POST['pin_office'])) {
        $valid = 0;
        $error_message .= "You must have to select a Bank Name<br>";
    }

	
    if($valid == 1) {

    	// Getting auto increment id for this category
		$statement = $pdo->prepare("SHOW TABLE STATUS LIKE 'pin_details'");
		$statement->execute();
		$result = $statement->fetchAll();
		foreach($result as $row) {
			$ai_id=$row[10];
		}


    	
    	
		// Saving data into the main table pin_details
		$statement = $pdo->prepare("INSERT INTO pin_details (pin_office,pin_code,pin_taluk,pin_type,pin_state,pin_district,pin_officetype, pin_contact, pin_delivery, pin_division, pin_region, pin_circle, state_short) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
		$statement->execute(array($_POST['pin_office'],$_POST['pin_code'],$_POST['pin_taluk'],$_POST['pin_type'],$_POST['pin_state'],$_POST['pin_district'],$_POST['pin_officetype'],$_POST['pin_contact'],$_POST['pin_delivery'],$_POST['pin_division'],$_POST['pin_region'],$_POST['pin_circle'],$_POST['state_short']));
	

    	$success_message = 'Post Office Details is added successfully.';
    }
}
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Add Post Office Details</h1>
	</div>
	<div class="content-header-right">
		<a href="office.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<section class="content">

	<div class="row">
		<div class="col-md-12">

			<?php if($error_message): ?>
			<div class="callout callout-danger">
			<h4>Please correct the following errors:</h4>
			<p>
			<?php echo $error_message; ?>
			</p>
			</div>
			<?php endif; ?>

			<?php if($success_message): ?>
			<div class="callout callout-success">
			<h4>Success:</h4>
			<p><?php echo $success_message; ?></p>
			</div>
			<?php endif; ?>

			<form class="form-horizontal" action="" method="post">

				<div class="box box-info">
					<div class="box-body">

						<div class="form-group">
							<label for="" class="col-sm-2 control-label">PIN Code<span>*</span> </label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="pin_code">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Post Office<span>*</span> </label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pin_office">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Office 1st Alphabet<span>*</span> </label>
							<div class="col-sm-4">
							
								<input type="text" class="form-control" name="pin_type" onkeyup="var start = this.selectionStart; var end = this.selectionEnd; this.value = this.value.toUpperCase(); this.setSelectionRange(start, end);">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">District<span>*</span> </label>
							<div class="col-sm-4">
							<select class="form-control" name="pin_district">
									<option value="">Select a District Name</option>
									
									<?php
									$statement = $pdo->prepare("SELECT * FROM state_details ORDER BY pin_district ASC");
									$statement->execute();
									$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
									foreach ($result as $row) {
										echo '<option value="'.$row['pin_district'].'">'.$row['pin_district'].'</option>';
									}
									?>
								</select>
								
							</div>
							<a href="district-add.php" class="btn btn-primary btn-sm">Add District Name</a>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">State <span>*</span></label>
							<div class="col-sm-4">

								<select class="form-control" name="pin_state">
									<option value="">Select a State Name</option>
									<option value="ANDAMAN AND NICOBAR ISLANDS">ANDAMAN AND NICOBAR ISLANDS</option>
									<option value="ANDHRA PRADESH">ANDHRA PRADESH</option>
									<option value="ARUNACHAL PRADESH">ARUNACHAL PRADESH</option>
									<option value="ASSAM">ASSAM</option>
									<option value="BIHAR">BIHAR</option>
									<option value="CHANDIGARH">CHANDIGARH</option>
									<option value="CHHATTISGARH">CHHATTISGARH</option>
									<option value="DADRA AND NAGAR HAVELI">DADRA AND NAGAR HAVELI</option>
									<option value="DAMAN And DIU">DAMAN And DIU</option>
									<option value="DELHI">DELHI</option>
									<option value="GOA">GOA</option>
									<option value="GUJARAT">GUJARAT</option>
									<option value="HARYANA">HARYANA</option>
									<option value="HIMACHAL PRADESH">HIMACHAL PRADESH</option>
									<option value="JAMMU AND KASHMIR">JAMMU AND KASHMIR</option>
									<option value="JHARKHAND">JHARKHAND</option>
									<option value="KARNATAKA">KARNATAKA</option>
									<option value="KERALA">KERALA</option>
									<option value="LAKSHADWEEP">LAKSHADWEEP</option>
									<option value="MADHYA PRADESH">MADHYA PRADESH</option>
									<option value="MAHARASHTRA">MAHARASHTRA</option>
									<option value="MANIPUR">MANIPUR</option>
									<option value="MEGHALAYA">MEGHALAYA</option>
									<option value="MIZORAM">MIZORAM</option>
									<option value="NAGALAND">NAGALAND</option>
									<option value="ODISHA">ODISHA</option>
									<option value="PONDICHERRY">PONDICHERRY</option>
									<option value="PUNJAB">PUNJAB</option>
									<option value="RAJASTHAN">RAJASTHAN</option>
									<option value="SIKKIM">SIKKIM</option>
									<option value="TAMIL NADU">TAMIL NADU</option>
									<option value="TELANGANA">TELANGANA</option>
									<option value="TRIPURA">TRIPURA</option>
									<option value="UTTAR PRADESH">UTTAR PRADESH</option>
									<option value="UTTARAKHAND">UTTARAKHAND</option>
									<option value="WEST BENGAL">WEST BENGAL</option>

								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">State Short Name</label>
							<div class="col-sm-4">
								<select class="form-control" name="state_short">
									<option value="">Select a State Short Name</option>
									<option value="AN"> AN / ANDAMAN AND NICOBAR ISLANDS</option>
									<option value="AP"> AP / ANDHRA PRADESH</option>
									<option value="AR"> AR / ARUNACHAL PRADESH</option>
									<option value="AS"> AS / ASSAM</option>
									<option value="BR"> BR / BIHAR</option>
									<option value="CG"> CG / CHANDIGARH</option>
									<option value="CH"> CH / CHHATTISGARH</option>
									<option value="DD"> DD / DAMAN And DIU</option>
									<option value="DH"> DH / DADRA AND NAGAR HAVELI</option>
									<option value="DL"> DL / DELHI</option>
									<option value="GA"> GA / GOA</option>
									<option value="GJ"> GJ / GUJARAT</option>
									<option value="HP"> HP / HIMACHAL PRADESH</option>
									<option value="HR"> HR / HARYANA</option>
									<option value="JH"> JH / JHARKHAND</option>
									<option value="JK"> JK / JAMMU AND KASHMIR</option>
									<option value="KA"> KA / KARNATAKA</option>
									<option value="KL"> KL / KERALA</option>
									<option value="LD"> LD / LAKSHADWEEP</option>
									<option value="MH"> MH / MAHARASHTRA</option>
									<option value="ML"> ML / MEGHALAYA</option>
									<option value="MN"> MN / MANIPUR</option>
									<option value="MP"> MP / MADHYA PRADESH</option>
									<option value="MZ"> MZ / MIZORAM</option>
									<option value="NL"> NL / NAGALAND</option>
									<option value="OD"> OD / ODISHA</option>
									<option value="PB"> PB / PUNJAB</option>
									<option value="PY"> PY / PONDICHERRY</option>
									<option value="RJ"> RJ / RAJASTHAN</option>
									<option value="SK"> SK / SIKKIM</option>
									<option value="TN"> TN / TAMIL NADU</option>
									<option value="TR"> TR / TRIPURA</option>
									<option value="TS"> TS / TELANGANA</option>
									<option value="UK"> UK / UTTARAKHAND</option>
									<option value="UP"> UP / UTTAR PRADESH</option>
									<option value="WB"> WB / WEST BENGAL</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Taluk </label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pin_taluk">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Post Office Type</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pin_officetype">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Contact Number</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="pin_contact">
							</div>
						</div>
						<div class="form-group">
						<label for="" class="col-sm-2 control-label">Delivery Status</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pin_delivery">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Postal Division</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pin_division">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Postal Region</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pin_region">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Postal Circle</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pin_circle">
							</div>
						</div>
						
						<div class="form-group">
							<label for="" class="col-sm-2 control-label"></label>
							<div class="col-sm-6">
								<button type="submit" class="btn btn-success pull-left" name="form1">Submit</button>
							</div>
						</div>
					</div>
				</div>

			</form>


		</div>
	</div>

</section>

<?php require_once('footer.php'); ?>