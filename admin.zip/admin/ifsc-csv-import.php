<?php 
include_once '../config/config.php';

	if(isset($_POST["ifsc_import"])) {
	
		if($_FILES['file']['name']) {
			
			$filename = explode(".", $_FILES['file']['name']);

				if($filename[1] == 'csv') {
	
				$handle = fopen($_FILES['file']['tmp_name'], "r");
				
					fgetcsv($handle); // Skipping header row
				
					 $totalInserted = 0;
					
					while(($column = fgetcsv($handle))!== FALSE) {

						$bank			=	$column[0];
	        	 		$bank_ifsc		=	$column[1];
	        	 		$bank_micr		=	$column[2];
	        	 		$branch			=	$column[3];
	        	 		$bank_address	=	$column[4];
						$city    		=	$column[5];
						$district    	=	$column[6];
						$state    		=	$column[7];
						$bank_contact	=	$column[8];

						$bank_name = preg_replace('/[^a-zA-Z0-9]/', ' ', $bank);
						$bank_branch = preg_replace('/[^a-zA-Z0-9]/', ' ', $branch);
						$bank_city = preg_replace('/[^a-zA-Z0-9]/', ' ', $city);
						$bank_district = preg_replace('/[^a-zA-Z0-9]/', ' ', $district);
						$bank_state = preg_replace('/[^a-zA-Z0-9]/', ' ', $state);
						
						$query 	= "INSERT INTO bank_details (bank_name, bank_ifsc, bank_micr, bank_branch, bank_address, bank_contact, bank_city, bank_district, bank_state) VALUES ('$bank_name', '$bank_ifsc', '$bank_micr', '$bank_branch', '$bank_address', '$bank_contact', '$bank_city', '$bank_district',  '$bank_state') ";
						//insert data from CSV file 

						mysqli_query($dbconn, $query);
						
						 $totalInserted ++;
					}
				fclose($handle);
				
				$success_message = "IFSC Code Data imported successfully. You have inserted <strong>". $totalInserted ."</strong> Branches Details";
				
			}else{
				$error_message = "Sorry! There is some problem ";
		}
	}
}
?>

<form method="post" enctype="multipart/form-data">
		<?php if($error_message): ?>
			<div class="callout callout-danger">
			
			<p>
			<?php echo $error_message; ?>
			</p>
			</div>
			<?php endif; ?>

			<?php if($success_message): ?>
			<div class="callout callout-success">
			
			<p><?php echo $success_message; ?></p>
			</div>
			<?php endif; ?>
			<div class="box box-info">
                <div class="box-body">
						    <div class="form-group">
                              <div class="col-sm-12" style="padding-top:6px;">
                                 <p>If you want to import full IFSC Code Branch Details CSV file then first empty bank_details database table <a href="#tab_3" data-toggle="tab">Go To Database Clean Tab</a> </p> 
                              </div>
                           </div>
						   <div class="form-group">
                              <label class="col-sm-2 control-label">Select CSV File</label>
                              <div class="col-sm-4">
                                 <input type="file" name="file" class="form-control">
                              </div>
                              <div class="col-sm-6">
							  <input type="submit" name="ifsc_import" class="btn btn-success" value="Import Data">

                              </div>
                           </div>
									
				</div>		
			</div>
		</form>
		
