<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
	$valid = 1;

    if(empty($_POST['pin_state'])) {
        $valid = 0;
        $error_message .= "State Name can not be empty<br>";
    } else {
		// Duplicate State checking
    	// current State name that is in the database
    	$statement = $pdo->prepare("SELECT * FROM pin_details WHERE pin_id=?");
		$statement->execute(array($_REQUEST['id']));
		$result = $statement->fetchAll(PDO::FETCH_ASSOC);
		foreach($result as $row) {
			$current_pin_state = $row['pin_state'];
		}

    }

    if($valid == 1) {

    	
		// updating into the database
		$statement = $pdo->prepare("UPDATE pin_details SET pin_state=?, pin_code=?, pin_taluk=?, pin_office=?, pin_type=?, pin_district=?, pin_officetype=?, pin_contact=?, pin_delivery=?, pin_division=?, pin_region=?, pin_circle=?, state_short=?   WHERE pin_id=?");
		$statement->execute(array($_POST['pin_state'],$_POST['pin_code'],$_POST['pin_taluk'],$_POST['pin_office'],$_POST['pin_type'],$_POST['pin_district'],$_POST['pin_officetype'],$_POST['pin_contact'],$_POST['pin_delivery'],$_POST['state_short'],$_POST['pin_region'],$_POST['pin_circle'],$_POST['pin_delivery'],$_REQUEST['id']));

    	$success_message = 'Post Office Details is updated successfully.';
    }
}
?>

<?php
if(!isset($_REQUEST['id'])) {
	header('location: logout.php');
	exit;
} else {
	// Check the id is valid or not
	$statement = $pdo->prepare("SELECT * FROM pin_details WHERE pin_id=?");
	$statement->execute(array($_REQUEST['id']));
	$total = $statement->rowCount();
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);
	if( $total == 0 ) {
		header('location: logout.php');
		exit;
	}
}
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Edit Post Office Details</h1>
	</div>
	<div class="content-header-right">
		<a href="office.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<?php							
foreach ($result as $row) {
	$pin_state = $row['pin_state'];
	$pin_code = $row['pin_code'];
	$pin_taluk = $row['pin_taluk'];
	$pin_office = $row['pin_office'];
	$pin_type = $row['pin_type'];
	$pin_district = $row['pin_district'];
	$pin_officetype = $row['pin_officetype'];
	$pin_contact = $row['pin_contact'];
	$pin_delivery = $row['pin_delivery'];
	$pin_division = $row['pin_division'];
	$pin_region = $row['pin_region'];
	$pin_circle = $row['pin_circle'];
	$state_short = $row['state_short'];
}
?>

<section class="content">

  <div class="row">
    <div class="col-md-12">

		<?php if($error_message): ?>
		<div class="callout callout-danger">
		<h4>Please correct the following errors:</h4>
		<p>
		<?php echo $error_message; ?>
		</p>
		</div>
		<?php endif; ?>

		<?php if($success_message): ?>
		<div class="callout callout-success">
		<h4>Success:</h4>
		<p><?php echo $success_message; ?></p>
		</div>
		<?php endif; ?>

        <form class="form-horizontal" action="" method="post">

        <div class="box box-info">

            <div class="box-body">
               
               <div class="form-group">
					<label for="" class="col-sm-2 control-label">PIN Code<span>*</span> </label>
					<div class="col-sm-6">
						<input type="text" class="form-control"  name="pin_code" value="<?php echo $pin_code; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Post Office <span>*</span></label>
					<div class="col-sm-6">
						<input type="text" class="form-control"  name="pin_office" value="<?php echo $pin_office; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Office 1st Alphabet <span>*</span></label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_type" value="<?php echo $pin_type; ?>">
					</div>
				</div>
				 <div class="form-group">
                    <label for="" class="col-sm-2 control-label">State Name <span>*</span></label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="pin_state" value="<?php echo $pin_state; ?>">
                    </div>
                </div>
				<div class="form-group">
                    <label for="" class="col-sm-2 control-label">State Short Name <span>*</span></label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="state_short" value="<?php echo $state_short; ?>">
                    </div>
                </div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">District <span>*</span></label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_district" value="<?php echo $pin_district; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Taluk </label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_taluk" value="<?php echo $pin_taluk; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Post Office Type</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_officetype" value="<?php echo $pin_officetype; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Contact Number </label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_contact" value="<?php echo $pin_contact; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Delivery Status</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_delivery" value="<?php echo $pin_delivery; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Postal Division</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_division" value="<?php echo $pin_division; ?>">
					</div>
				</div>
                <div class="form-group">
					<label for="" class="col-sm-2 control-label">Postal Region</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_region" value="<?php echo $pin_region; ?>">
					</div>
				</div>
                <div class="form-group">
					<label for="" class="col-sm-2 control-label">Postal Circle</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" name="pin_circle" value="<?php echo $pin_circle; ?>">
					</div>
				</div>				
                <div class="form-group">
                	<label for="" class="col-sm-2 control-label"></label>
                    <div class="col-sm-6">
                      <button type="submit" class="btn btn-success pull-left" name="form1">Update</button>
                    </div>
                </div>

            </div>

        </div>

        </form>



    </div>
  </div>

</section>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
            </div>
            <div class="modal-body">
                Are you sure want to delete this item?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>