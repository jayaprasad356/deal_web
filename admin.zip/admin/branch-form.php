<?php 
	
	// including db config file
	

	// including import controller file
	include_once 'ifsc-csv-import.php';


    // creating object of import controller and passing connection object as a parameter
	$importCtrl      =    	new ImportController($dbconn);

?>

				  
		<form method="post" enctype="multipart/form-data">
		<?php if($error_message): ?>
			<div class="callout callout-danger">
			
			<p>
			<?php echo $error_message; ?>
			</p>
			</div>
			<?php endif; ?>

			<?php if($success_message): ?>
			<div class="callout callout-success">
			
			<p><?php echo $success_message; ?></p>
			</div>
			<?php endif; ?>
			<div class="box box-info">
                <div class="box-body">
						    <div class="form-group">
                              <div class="col-sm-12" style="padding-top:6px;">
                                 <p>If you want to import full Bank Details CSV file then first empty Bank_details database table <a href="#tab_3" data-toggle="tab">Go To Database Clean Tab</a> </p> 
                              </div>
                           </div>
						   <div class="form-group">
                              <label class="col-sm-2 control-label">Select CSV File</label>
                              <div class="col-sm-4">
                                 <input type="file" name="file" class="form-control">
                              </div>
                              <div class="col-sm-6">
                               <button type="submit" name="import" class="btn btn-success"> Import Data </button>
                                 
                              </div>
                           </div>
									
				</div>		
			</div>

			<div class="row mt-4">
				<div class="col-md-10 m-auto">
					<?php

						$importResult   =  $importCtrl->index(); 	
											
					?>
				</div>
			</div>	
		</form>
