<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
	$valid = 1;

    if(empty($_POST['bank_name'])) {
        $valid = 0;
        $error_message .= "Bank Name can not be empty<br>";
    } else {
    	// Duplicate Category checking
    	$statement = $pdo->prepare("SELECT * FROM contact_details WHERE bank_name=?");
    	$statement->execute(array($_POST['bank_name']));
    	$total = $statement->rowCount();
    	if($total)
    	{
    		$valid = 0;
        	$error_message .= "Bank Name already exists<br>";
    	}
    }

    if($valid == 1) {

    	// Getting auto increment id for this category
		$statement = $pdo->prepare("SHOW TABLE STATUS LIKE 'contact_details'");
		$statement->execute();
		$result = $statement->fetchAll();
		foreach($result as $row) {
			$ai_id=$row[10];
		}
		
		// Saving data into the main table contact_details
		$statement = $pdo->prepare("INSERT INTO contact_details (bank_name,bank_content,bank_customer,bank_website,bank_email,bank_fax) VALUES (?,?,?,?,?,?)");
		$statement->execute(array($_POST['bank_name'],$_POST['bank_content'],$_POST['bank_customer'],$_POST['bank_website'],$_POST['bank_email'],$_POST['bank_fax']));
	

    	$success_message = 'Bank Details is added successfully.';
    }


}
?>
<?php

if(isset($_POST['form1']))
{ 

$extension = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
$name = $_POST["bank_name"];
$img_name = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '_', $name));

move_uploaded_file($_FILES["file"]["tmp_name"], "../assets/images/bank-logos/" .$img_name.".".$extension);
}
?>
<section class="content-header">
	<div class="content-header-left">
		<h1>Add Bank Details</h1>
	</div>
	<div class="content-header-right">
		<a href="bank.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<section class="content">Not Available in free version.</section>

<?php require_once('footer.php'); ?>