<?php
include("../config/config.php");
//process.php


$query = "SELECT * FROM contact_details";

$statement = $pdo->prepare($query);

$statement->execute();

echo $statement->rowCount();

?>