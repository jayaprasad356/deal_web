<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
	$valid = 1;

	$path = $_FILES['photo_logo']['name'];
    $path_tmp = $_FILES['photo_logo']['tmp_name'];

    if($path == '') {
    	$valid = 0;
        $error_message .= 'You must have to select a photo<br>';
    } else {
        $ext = pathinfo( $path, PATHINFO_EXTENSION );
        $file_name = basename( $path, '.' . $ext );
        if( $ext!='jpg' && $ext!='png' && $ext!='jpeg' && $ext!='gif' ) {
            $valid = 0;
            $error_message .= 'You must have to upload jpg, jpeg, gif or png file<br>';
        }
    }

    if($valid == 1) {
    	// removing the existing photo
    	$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
    	$statement->execute();
    	$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
    	foreach ($result as $row) {
    		$logo = $row['logo'];
    		unlink('../assets/uploads/'.$logo);
    	}

    	// updating the data
    	$final_name = 'logo'.'.'.$ext;
        move_uploaded_file( $path_tmp, '../assets/uploads/'.$final_name );

        // updating the database
		$statement = $pdo->prepare("UPDATE tbl_settings SET logo=? WHERE id=1");
		$statement->execute(array($final_name));

        $success_message = 'Logo is updated successfully.';
    	
    }
}
if(isset($_POST['mobile_logo'])) {
	$valid = 1;

	$path = $_FILES['mobile_photo_logo']['name'];
    $path_tmp = $_FILES['mobile_photo_logo']['tmp_name'];

    if($path == '') {
    	$valid = 0;
        $error_message .= 'You must have to select a photo<br>';
    } else {
        $ext = pathinfo( $path, PATHINFO_EXTENSION );
        $file_name = basename( $path, '.' . $ext );
        if( $ext!='jpg' && $ext!='png' && $ext!='jpeg' && $ext!='gif' ) {
            $valid = 0;
            $error_message .= 'You must have to upload jpg, jpeg, gif or png file<br>';
        }
    }

    if($valid == 1) {
    	// removing the existing photo
    	$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
    	$statement->execute();
    	$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
    	foreach ($result as $row) {
    		$mobile_logo = $row['mobile_logo'];
    		unlink('../assets/uploads/'.$mobile_logo);
    	}

    	// updating the data
    	$final_name = 'mobile_logo'.'.'.$ext;
        move_uploaded_file( $path_tmp, '../assets/uploads/'.$final_name );

        // updating the database
		$statement = $pdo->prepare("UPDATE tbl_settings SET logo_width=?, logo_height=?, mobile_logo=? WHERE id=1");
		$statement->execute(array($_POST['logo_width'],$_POST['logo_height'],$final_name));

        $success_message = 'Mobile Logo is updated successfully.';
    	
    }
}
if(isset($_POST['form2'])) {
	$valid = 1;

	$path = $_FILES['photo_favicon']['name'];
    $path_tmp = $_FILES['photo_favicon']['tmp_name'];

    if($path == '') {
    	$valid = 0;
        $error_message .= 'You must have to select a photo<br>';
    } else {
        $ext = pathinfo( $path, PATHINFO_EXTENSION );
        $file_name = basename( $path, '.' . $ext );
        if( $ext!='jpg' && $ext!='png' && $ext!='jpeg' && $ext!='gif' ) {
            $valid = 0;
            $error_message .= 'You must have to upload jpg, jpeg, gif or png file<br>';
        }
    }

    if($valid == 1) {
    	// removing the existing photo
    	$statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
    	$statement->execute();
    	$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
    	foreach ($result as $row) {
    		$favicon = $row['favicon'];
    		unlink('../assets/uploads/'.$favicon);
    	}

    	// updating the data
    	$final_name = 'favicon'.'.'.$ext;
        move_uploaded_file( $path_tmp, '../assets/uploads/'.$final_name );

        // updating the database
		$statement = $pdo->prepare("UPDATE tbl_settings SET favicon=? WHERE id=1");
		$statement->execute(array($final_name));

        $success_message = 'Favicon is updated successfully.';
    	
    }
}

if(isset($_POST['sitename'])) {
	
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET site_title=?, logo_status=? WHERE id=1");
	$statement->execute(array($_POST['site_title'],$_POST['logo_status']));

	$success_message = 'Site Name settings is updated successfully.';
    
}
if(isset($_POST['form3'])) {
	
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET contact_address=?, contact_email=?, contact_phone=?, contact_map_iframe=?,author_name=? WHERE id=1");
	$statement->execute(array($_POST['contact_address'],$_POST['contact_email'],$_POST['contact_phone'],$_POST['contact_map_iframe'], $_POST['author_name']));

	$success_message = 'General content settings is updated successfully.';
    
}

if(isset($_POST['form4'])) {
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET receive_email=?, receive_email_subject=?,receive_email_thank_you_message=? WHERE id=1");
	$statement->execute(array($_POST['receive_email'],$_POST['receive_email_subject'],$_POST['receive_email_thank_you_message']));

	$success_message = 'Contact form settings information is updated successfully.';
}


if(isset($_POST['form5'])) {
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET recent_news_footer=?, popular_news_footer=?, recent_news_sidebar=?, popular_news_sidebar=?, recent_news_home_page=? WHERE id=1");
	$statement->execute(array($_POST['recent_news_footer'],$_POST['popular_news_footer'],$_POST['recent_news_sidebar'],$_POST['popular_news_sidebar'],$_POST['recent_news_home_page']));

	$success_message = 'Sidebar settings is updated successfully.';
}


if(isset($_POST['form8'])) {
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET mod_rewrite=? WHERE id=1");
	$statement->execute(array($_POST['mod_rewrite']));

	$success_message = 'Mod Rewrite settings is updated successfully.';
}

if(isset($_POST['form9'])) {
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET news_sidebar_status=?, pin_sidebar_status=?, ifsc_sidebar_status=?, swift_sidebar_status=?, sidebar_widget_status=?, sidebar_widget_title=?,sidebar_widget_code=? WHERE id=1");
	$statement->execute(array($_POST['news_sidebar_status'],$_POST['pin_sidebar_status'],$_POST['ifsc_sidebar_status'],$_POST['swift_sidebar_status'],$_POST['sidebar_widget_status'],$_POST['sidebar_widget_title'],$_POST['sidebar_widget_code']));

	$success_message = 'Sidebar settings is updated successfully.';
} 

 

if(isset($_POST['form7'])) {
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET google=?, bing=?, yandex=? WHERE id=1");
	$statement->execute(array($_POST['google'],$_POST['bing'],$_POST['yandex']));

	$success_message = 'Webmaster Tools settings is updated successfully.';
}
if(isset($_POST['form10'])) {
	// updating the database
	$statement = $pdo->prepare("UPDATE tbl_settings SET footer_code=?, header_code=? WHERE id=1");
	$statement->execute(array($_POST['footer_code'],$_POST['header_code']));

	$success_message = 'Custom Code settings is updated successfully.';
}

?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Settings</h1>
	</div>
</section>




<section class="content" style="min-height:auto;margin-bottom: -30px;">
	<div class="row">
		<div class="col-md-12">
			<?php if($error_message): ?>
			<div class="callout callout-danger">
			
			<p>
			<?php echo $error_message; ?>
			</p>
			</div>
			<?php endif; ?>

			<?php if($success_message): ?>
			<div class="callout callout-success">
			
			<p><?php echo $success_message; ?></p>
			</div>
			<?php endif; ?>
		</div>
	</div>
</section>

<section class="content">

	<div class="row">
		<div class="col-md-12">
							
				<div class="nav-tabs-custom">
					<ul class="nav nav-tabs">
						<li class="active"><a href="#tab_1" data-toggle="tab">Download Database</a></li>
						<li><a href="#tab_2" data-toggle="tab">Update Databse</a></li>
						
						
					</ul>
					<div class="tab-content">
          				<div class="tab-pane active" id="tab_1">

   <div class="ifsc-div-1">
		<form method="post" onsubmit="return ray.ajax()">
			<h2>Download And Update Bank IFSC Code Database</h2>
			<div id="load" style="display:none;">Loading... Please wait</div>
				<input type="submit" name="ifsc_download" id="ifsc_download" value="Download!" class="button-primary">		
		</form>
	</div>
		
	
<script type="text/javascript">
var ray={
ajax:function(st)
	{
		this.show('load');
	},
show:function(el)
	{
		this.getID(el).style.display='';
	},
getID:function(el)
	{
		return document.getElementById(el);
	}
}
</script>
<?php
    // maximum execution time in seconds
    set_time_limit (24 * 60 * 60);

    if (!isset($_POST['ifsc_download'])) 
		
	die();

    // folder to save downloaded files to. must end with slash
    $destination_folder = dirname( __FILE__ ) . '/import/';

    $url = 'https://www.acchibaat.com/assets/uploads/db_ifsc_details.gz';
    $newfname = $destination_folder . basename($url);

    $file = fopen ($url, "rb");
    if ($file) {
      $newf = fopen ($newfname, "wb");
		echo "<script>alert('Database Downloaded Successfully')</script>";
		
      if ($newf)
      while(!feof($file)) {
        fwrite($newf, fread($file, 1024 * 8 ), 1024 * 8 );
      }
	   //echo "loding";
    }

    if ($file) {
      fclose($file);
	 
    }

    if ($newf) {
      fclose($newf);
	  
    } ?>
	

          				</div>
          				<div class="tab-pane" id="tab_2">

          					
		<form action="" method="post">
			<div class="ifsc-div-1">
				<h2>Import IFSC Code Database</h2>
				<input type="submit" name="import" id="import" value="Import!" class="button-primary">
			</div>
        </form>
<?php 		
 if ( isset( $_POST['import'] ) ) {

	global $dbconn;
		//$oj_db_files = file($filename);
		$oj_db_files = gzfile( dirname( __FILE__ ) . '/import/db_ifsc_details.gz' );
		$oj_tempLine = '';
		
		// Loop through each line
		foreach ($oj_db_files as $file) {

    // Skip it if it's a comment
			if (substr($file, 0, 2) == '--' || $file == '')
			continue;

			// Add this line to the current segment
			$oj_tempLine .= $file;
			// If its semicolon at the end, so that is the end of one query
		if (substr(trim($file), -1, 1) == ';')  {
        // Perform the query
        $wpdb->query($oj_tempLine) or print("Error in " . $oj_tempLine);
        // Reset temp variable to empty
        $oj_tempLine = '';
    }
}
		echo "<script>alert('Database Tables Imported successfully')</script>";
		
		
 }
 
?>


          				</div>
          				



          			</div>
				</div>

			
		</div>
	</div>

</section>

<?php require_once('footer.php'); ?>