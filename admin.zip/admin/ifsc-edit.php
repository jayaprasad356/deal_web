<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
	$valid = 1;

    if(empty($_POST['bank_name'])) {
        $valid = 0;
        $error_message .= "Bank Name can not be empty<br>";
    } else {
		// Duplicate Bank checking
    	// current Bank name that is in the database
    	$statement = $pdo->prepare("SELECT * FROM bank_details WHERE bank_id=?");
		$statement->execute(array($_REQUEST['id']));
		$result = $statement->fetchAll(PDO::FETCH_ASSOC);
		foreach($result as $row) {
			$current_bank_name = $row['bank_name'];
		}

    }

    if($valid == 1) {

    	
    	
		// updating into the database
		$statement = $pdo->prepare("UPDATE bank_details SET bank_name=?, bank_ifsc=?, bank_micr=?, bank_branch=?, bank_state=?, bank_district=?, bank_city=?, bank_contact=?, bank_address=?   WHERE bank_id=?");
		$statement->execute(array($_POST['bank_name'],$_POST['bank_ifsc'],$_POST['bank_micr'],$_POST['bank_branch'],$_POST['bank_state'],$_POST['bank_district'],$_POST['bank_city'],$_POST['bank_contact'],$_POST['bank_address'],$_REQUEST['id']));

    	$success_message = 'Bank Details is updated successfully.';
    }
}
?>

<?php
if(!isset($_REQUEST['id'])) {
	header('location: logout.php');
	exit;
} else {
	// Check the id is valid or not
	$statement = $pdo->prepare("SELECT * FROM bank_details WHERE bank_id=?");
	$statement->execute(array($_REQUEST['id']));
	$total = $statement->rowCount();
	$result = $statement->fetchAll(PDO::FETCH_ASSOC);
	if( $total == 0 ) {
		header('location: logout.php');
		exit;
	}
}
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Edit Bank Details</h1>
	</div>
	<div class="content-header-right">
		<a href="ifsc.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<?php							
foreach ($result as $row) {
	$bank_name = $row['bank_name'];
	$bank_ifsc = $row['bank_ifsc'];
	$bank_micr = $row['bank_micr'];
	$bank_branch = $row['bank_branch'];
	$bank_state = $row['bank_state'];
	$bank_district = $row['bank_district'];
	$bank_city = $row['bank_city'];
	$bank_contact = $row['bank_contact'];
	$bank_address = $row['bank_address'];
}
?>

<section class="content">

  <div class="row">
    <div class="col-md-12">

		<?php if($error_message): ?>
		<div class="callout callout-danger">
		<h4>Please correct the following errors:</h4>
		<p>
		<?php echo $error_message; ?>
		</p>
		</div>
		<?php endif; ?>

		<?php if($success_message): ?>
		<div class="callout callout-success">
		<h4>Success:</h4>
		<p><?php echo $success_message; ?></p>
		</div>
		<?php endif; ?>

        <form class="form-horizontal" action="" method="post">

        <div class="box box-info">

            <div class="box-body">
                <div class="form-group">
                    <label for="" class="col-sm-2 control-label">Bank Name <span>*</span></label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="bank_name" value="<?php echo $bank_name; ?>">
                    </div>
                </div>
               <div class="form-group">
					<label for="" class="col-sm-2 control-label">IFSC Code<span>*</span> </label>
					<div class="col-sm-9">
						<input type="text" class="form-control"  name="bank_ifsc" value="<?php echo $bank_ifsc; ?>">
					</div>
				</div>
				
                
                <div class="form-group">
					<label for="" class="col-sm-2 control-label">MICR Code </label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_micr" value="<?php echo $bank_micr; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Branch <span>*</span></label>
					<div class="col-sm-9">
						<input type="text" class="form-control"  name="bank_branch" value="<?php echo $bank_branch; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">State <span>*</span></label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_state" value="<?php echo $bank_state; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">District <span>*</span></label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_district" value="<?php echo $bank_district; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">City </label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_city" value="<?php echo $bank_city; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Contact Number </label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="bank_contact" value="<?php echo $bank_contact; ?>">
					</div>
				</div>
				<div class="form-group">
					<label for="" class="col-sm-2 control-label">Bank Address <span>*</span></label>
					<div class="col-sm-9">
						<textarea class="form-control" name="bank_address"><?php echo $bank_address; ?></textarea>
					</div>
				</div>
                <div class="form-group">
                	<label for="" class="col-sm-2 control-label"></label>
                    <div class="col-sm-6">
                      <button type="submit" class="btn btn-success pull-left" name="form1">Update</button>
                    </div>
                </div>

            </div>

        </div>

        </form>



    </div>
  </div>

</section>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
            </div>
            <div class="modal-body">
                Are you sure want to delete this item?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>