<?php require_once('header.php'); ?>

<?php
if(isset($_POST['form1'])) {
	$valid = 1;

    if(empty($_POST['bank_ifsc'])) {
        $valid = 0;
        $error_message .= "IFSC Code can not be empty<br>";
    } 
	if(empty($_POST['bank_state'])) {
        $valid = 0;
        $error_message .= "State can not be empty<br>";
    }

    if(empty($_POST['bank_district'])) {
        $valid = 0;
        $error_message .= "District code can not be empty<br>";
    }
    
    if(empty($_POST['bank_name'])) {
        $valid = 0;
        $error_message .= "You must have to select a Bank Name<br>";
    }
    if(empty($_POST['bank_branch'])) {
        $valid = 0;
        $error_message .= "Branch can not be emptybr>";
    }
	
    if($valid == 1) {

    	// Getting auto increment id for this category
		$statement = $pdo->prepare("SHOW TABLE STATUS LIKE 'bank_details'");
		$statement->execute();
		$result = $statement->fetchAll();
		foreach($result as $row) {
			$ai_id=$row[10];
		}


    	
    	
		// Saving data into the main table bank_details
		$statement = $pdo->prepare("INSERT INTO bank_details (bank_name,bank_ifsc,bank_micr,bank_branch,bank_state,bank_district,bank_city, bank_contact, bank_address) VALUES (?,?,?,?,?,?,?,?,?)");
		$statement->execute(array($_POST['bank_name'],$_POST['bank_ifsc'],$_POST['bank_micr'],$_POST['bank_branch'],$_POST['bank_state'],$_POST['bank_district'],$_POST['bank_city'],$_POST['bank_contact'],$_POST['bank_address']));
	

    	$success_message = 'Bank IFSC Details is added successfully.';
    }
}
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Add Bank IFSC Details</h1>
	</div>
	<div class="content-header-right">
		<a href="ifsc.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<section class="content">Not available in free version</section>

<?php require_once('footer.php'); ?>