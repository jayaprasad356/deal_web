<?php require_once('header.php'); ?>

<section class="content-header">
  <h1>Dashboard</h1>
</section>



<section class="content">

  <div class="row">
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Total Users</span>
          <span class="info-box-number">1</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="user.php" style="color:#fff;">View All Users <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
      </div>
    </div>
    
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Total Categories</span>
          <span class="info-box-number">3</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="category.php" style="color:#fff;">View All Categories <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
      </div>
    </div>


    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Total News</span>
          <span class="info-box-number">7</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="news.php" style="color:#fff;">View All News <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
      </div>
    </div>

    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Total Banks</span>
          <span class="info-box-number">223</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="https://www.acchibaat.com/code-finder/" style="color:#fff;">Buy Now <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
      </div>
    </div>

    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Total Branch</span>
          <span class="info-box-number">162676</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="https://www.acchibaat.com/code-finder/" style="color:#fff;">Buy Now <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Total Post Offices</span>
          <span class="info-box-number">154797</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="https://www.acchibaat.com/code-finder/" style="color:#fff;">Buy Now <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Total District</span>
          <span class="info-box-number">631</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="https://www.acchibaat.com/code-finder/" style="color:#fff;">Buy Now <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Swift Code</span>
          <span class="info-box-number">112867</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="https://www.acchibaat.com/code-finder/" style="color:#fff;">Buy Now <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
		
      </div>
    </div>
    
	<div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <div class="info-box-content bg-green">
          <span class="info-box-text">Sitemap</span>
          <span class="info-box-number">109</span>
        </div>
		<div class="info-box-content  bg-aqua">
          <span class="info-box-text"><a href="https://www.acchibaat.com/code-finder/" style="color:#fff;">Buy Now <i class="fa fa-arrow-circle-right"></i></a></span>
        </div>
		
      </div>
    </div>
   
  </div>


</section>

<?php require_once('footer.php'); ?>