<?php require_once('header.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<?php  if (isset($_POST['branch_clean'])) {
	 //echo "<script>alert('Database bank_details Empty')</script>";
	 
		$sql = "TRUNCATE TABLE bank_details";

		//Prepare the SQL query.
		$statement = $pdo->prepare($sql);
		 $success_message = 'IFSC Code Bank Details Table Empty successfully.';
		//Execute the statement.
		$statement->execute();
 }?>
 
  <?php  if (isset($_POST['bank_clean'])) {
	 //echo "<script>alert('Database bank_details Empty')</script>";
	
		$sql = "TRUNCATE TABLE contact_details";

		//Prepare the SQL query.
		$statement = $pdo->prepare($sql);
		 $success_message = 'Contact Details Table Empty successfully.';
		//Execute the statement.
		$statement->execute();

}

?>

<section class="content-header">
   <h1>Import CSV File Data</h1>
</section>
<section class="content" style="min-height:auto;margin-bottom: -30px;">
	<div class="row">
		<div class="col-md-12">
			<?php if($error_message): ?>
			<div class="callout callout-danger">
			
			<p>
			<?php echo $error_message; ?>
			</p>
			</div>
			<?php endif; ?>

			<?php if($success_message): ?>
			<div class="callout callout-success">
			
			<p><?php echo $success_message; ?></p>
			</div>
			<?php endif; ?>
		</div>
	</div>
</section>

<section class="content">Not Available in free version.</section>

