
                  <form class="form-horizontal" id="bank_form" method="post" enctype="multipart/form-data">
                     <div class="box box-info">
                        <div class="box-body">
                           <span id="message"></span>
						   
						    <div class="form-group">
                              <div class="col-sm-12" style="padding-top:6px;">
                                 <p>If you want to import full Contact Details CSV file then first empty contact_details database table <a href="#tab_3" data-toggle="tab">Go To Database Clean Tab</a> </p> 
                              </div>
                           </div>
                           <div class="form-group">
                              <label class="col-sm-2 control-label">Select CSV File</label>
                              <div class="col-sm-4">
                                 <input type="file" name="file" id="file" />
                              </div>
                              <div class="col-sm-6">
                                 <input type="hidden" name="bank_hidden_field" value="1" />
                                 <input type="submit" name="bank_import" id="bank_import" class="btn btn-info" value="Import" />
                              </div>
                           </div>
                           <div class="form-group" id="bank-process" style="display:none;">
                              <div class="progress">
                                 <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                    <span id="bank_process_data">0</span> - <span id="bank_total_data">0</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
<script>
 
 $(document).ready(function(){

  var clear_timer;

  $('#bank_form').on('submit', function(event){
   $('#message').html('');
   event.preventDefault();
   $.ajax({
    url:"bank-csv-upload.php",
    method:"POST",
    data: new FormData(this),
    dataType:"json",
    contentType:false,
    cache:false,
    processData:false,
    beforeSend:function(){
     $('#bank_import').attr('disabled','disabled');
     $('#bank_import').val('Importing');
    },
    success:function(data)
    {
     if(data.success)
     {
      $('#bank_total_data').text(data.total_line);

      start_import();

      clear_timer = setInterval(get_import_data, 2000);

      //$('#message').html('<div class="alert alert-success">CSV File Uploaded</div>');
     }
     if(data.error)
     {
      $('#message').html('<div class="alert alert-danger">'+data.error+'</div>');
      $('#bank_import').attr('disabled',false);
      $('#bank_import').val('Import');
     }
    }
   })
  });

  function start_import()
  {
   $('#bank-process').css('display', 'block');
   $.ajax({
    url:"bank-csv-import.php",
    success:function()
    {

    }
   })
  }

  function get_import_data()
  {
   $.ajax({
    url:"bank-csv-process.php",
    success:function(data)
    {
     var bank_total_data = $('#bank_total_data').text();
     var width = Math.round((data/bank_total_data)*100);
     $('#bank_process_data').text(data);
     $('.progress-bar').css('width', width + '%');
     if(width >= 100)
     {
      clearInterval(clear_timer);
      $('#bank-process').css('display', 'none');
      $('#file').val('');
      $('#message').html('<div class="alert alert-success">Bank Data Successfully Imported</div>');
      $('#bank_import').attr('disabled',false);
      $('#bank_import').val('Import');
     }
    }
   })
  }

 });
</script>



