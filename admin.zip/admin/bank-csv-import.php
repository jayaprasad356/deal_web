<?php
include("../config/config.php");

//import.php

header('Content-type: text/html; charset=utf-8');
header("Cache-Control: no-cache, must-revalidate");
header ("Pragma: no-cache");

set_time_limit(0);

ob_implicit_flush(1);

session_start();

if(isset($_SESSION['csv_file_name']))
{

 $file_data = fopen('file/' . $_SESSION['csv_file_name'], 'r');

 fgetcsv($file_data);

 while($row = fgetcsv($file_data))
 {
  $data = array(
   ':bank_name' => $row[0],
   ':bank_customer' => $row[1],
   ':bank_fax' => $row[2],
   ':bank_email' => $row[3],
   ':bank_website' => $row[4],
   ':bank_content' => $row[5]
   
  );

  $query = "
  INSERT INTO contact_details (bank_name, bank_customer, bank_fax, bank_email, bank_website, bank_content) 
     VALUES (:bank_name, :bank_customer, :bank_fax, :bank_email, :bank_website, :bank_content)
  ";

  $statement = $pdo->prepare($query);

  $statement->execute($data);

  sleep(1);

  if(ob_get_level() > 0)
  {
   ob_end_flush();
  }
 }

 unset($_SESSION['csv_file_name']);
}

?>