<?php require_once('header.php'); ?>
<script type="text/javascript">
	function search1() {

	    var sea=document.getElementById("search").value;

            if (sea==null || sea=="")
            {
                   alert("Search cannot be blank");
            }
            else
            {
                   window.location.href = "office-search.php?sea="+sea;
            }
	}	
</script>
<section class="content-header">
	<div class="content-header-left">
		<h1>View Post Office Details</h1>
	</div>
	 <div class="form-inline col-xs-4">
		<input type="text" class="form-control mr-sm-2" id="search" name="search" placeholder="Search...">
		<button onclick="search1()" class="btn my-2 my-sm-0 btn-primary">Search</button>
  </div>
	<div class="content-header-right">
		<a href="office-add.php" class="btn btn-primary btn-sm">Add New</a>
	</div>
</section>


<section class="content">Not Availabe in free version</section>


<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
            </div>
            <div class="modal-body">
                <p>Are you sure want to delete this item?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div>


<?php require_once('footer.php'); ?>